/* ===== SUBLIMARCE v3 — Shared JS ===== */
document.addEventListener('DOMContentLoaded', () => {

  /* ── Dark Mode ── */
  const dBtn = document.getElementById('darkModeToggle');
  function setDark(on) {
    document.body.classList.toggle('dark', on);
    if (dBtn) {
      dBtn.querySelector('.icon-moon').style.display = on ? 'none' : '';
      dBtn.querySelector('.icon-sun').style.display  = on ? '' : 'none';
    }
    localStorage.setItem('dm', on ? '1' : '0');
  }
  const saved = localStorage.getItem('dm');
  setDark(saved !== null ? saved === '1' : window.matchMedia('(prefers-color-scheme: dark)').matches);
  if (dBtn) dBtn.addEventListener('click', () => setDark(!document.body.classList.contains('dark')));

  /* ── Mobile Menu ── */
  const mBtn = document.getElementById('mobileMenuButton');
  const nav  = document.getElementById('mainNav');
  if (mBtn && nav) {
    mBtn.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      mBtn.setAttribute('aria-expanded', open);
    });
    nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));
  }

  /* ── Year ── */
  document.querySelectorAll('[data-year]').forEach(el => el.textContent = new Date().getFullYear());

  /* ── Smooth Scroll ── */
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const t = document.querySelector(a.getAttribute('href'));
      if (t) { e.preventDefault(); const off = document.getElementById('main-header')?.offsetHeight || 68; window.scrollTo({ top: t.offsetTop - off, behavior: 'smooth' }); }
    });
  });

  /* ── Active Nav (scroll-spy) ── */
  const sections  = document.querySelectorAll('section[id]');
  const navLinks  = document.querySelectorAll('#mainNav a');
  function updateNav() {
    const off = (document.getElementById('main-header')?.offsetHeight || 68) + 60;
    let cur = '';
    sections.forEach(s => { if (window.scrollY >= s.offsetTop - off) cur = s.id; });
    navLinks.forEach(a => {
      const href = a.getAttribute('href') || '';
      a.classList.toggle('active', cur && (href.endsWith('#' + cur) || href.endsWith(cur)));
    });
  }
  window.addEventListener('scroll', updateNav, { passive: true });
  updateNav();

  /* ── FAQ Accordion ── */
  document.querySelectorAll('.faq-question').forEach(q => {
    q.addEventListener('click', () => {
      const item = q.closest('.faq-item');
      const wasOpen = item.classList.contains('open');
      document.querySelectorAll('.faq-item.open').forEach(i => i.classList.remove('open'));
      if (!wasOpen) item.classList.add('open');
    });
  });

  /* ── Scroll Reveal ── */
  if ('IntersectionObserver' in window) {
    const obs = new IntersectionObserver(entries => {
      entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); obs.unobserve(e.target); } });
    }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });
    document.querySelectorAll('.reveal').forEach(el => obs.observe(el));
  } else {
    document.querySelectorAll('.reveal').forEach(el => el.classList.add('visible'));
  }

  /* ── Gallery Thumbs ── */
  document.querySelectorAll('.gallery-thumb').forEach(th => {
    th.addEventListener('click', () => {
      const img = document.getElementById('gallery-main-img');
      if (img && th.dataset.img) { img.src = th.dataset.img; }
      document.querySelectorAll('.gallery-thumb').forEach(t => t.classList.remove('active'));
      th.classList.add('active');
    });
  });

  /* ── Category Filter ── */
  document.querySelectorAll('[data-filter-group]').forEach(group => {
    const grid = document.getElementById(group.dataset.filterGroup);
    if (!grid) return;
    group.querySelectorAll('.cat-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        group.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const f = btn.dataset.filter;
        grid.querySelectorAll('.product-card').forEach(card => {
          card.style.display = (f === 'all' || (card.dataset.cat || '').includes(f)) ? '' : 'none';
        });
      });
    });
  });

  /* ── Sticky cat pills highlight ── */
  document.querySelectorAll('.cat-pill[onclick]').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('.cat-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
    });
  });

});

/* ── Scroll to cat anchor ── */
function scrollTo(id) {
  const el = document.getElementById(id);
  if (el) { const off = document.getElementById('main-header')?.offsetHeight || 68; window.scrollTo({ top: el.offsetTop - off - 48, behavior: 'smooth' }); }
}
