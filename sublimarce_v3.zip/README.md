# SUBLIMARCE - Sitio Web Rediseñado

## Estructura del Proyecto

```
sublimarce/
├── index.html                      # Página principal
├── gorras.html                     # Catálogo de gorras
├── llaveros.html                   # Catálogo de llaveros
├── gorra-trucker-frente-color.html # Detalle de producto (gorra trucker)
├── remeras.html                    # (existente, mantener)
├── tazas.html                      # (existente, mantener)
├── style.css                       # Stylesheet global (unificado)
├── main.js                         # JavaScript compartido
├── Logosublimarce.jpg              # Logo
├── gorranegra.webp                 # Imágenes de productos
├── GORRAAMARILLA.webp
├── gorra_roja.jpeg
├── ROJO-GORRO-TRUCKER-FRENTE-DE-COLOR.jpg
└── QR_ORIGINAL.svg                 # QR code
```

## Cambios Realizados

### Arquitectura y Código
- **CSS unificado** en un único `style.css` con variables CSS (custom properties) para toda la marca
- **JS compartido** en `main.js` — dark mode, menú mobile, scroll reveal, FAQ accordion, galería de producto
- **Sin Tailwind CDN** — CSS puro propio, más rápido y sin dependencias externas en runtime
- **Lazy loading** en todas las imágenes (`loading="lazy"`)

### Diseño y UX
- **Paleta nueva**: Rojo/naranja vibrante + fondo cálido (crema) + negro profundo — acorde a sublimación
- **Tipografía**: Bebas Neue (display) + DM Sans (cuerpo) — par distintivo y legible
- **Mobile First**: Header responsive, nav collapsible, grids flexibles
- **Dark Mode** mejorado con persistencia en localStorage

### Conversión y Ventas
- **Botón WhatsApp flotante** en todas las páginas
- **CTAs dinámicos**: En detalle de gorra, el mensaje de WhatsApp se actualiza con color y cantidad
- **Filtros de categoría** en gorras y llaveros (JavaScript nativo, sin dependencias)
- **Selector de cantidad** con descuentos automáticos por volumen

### SEO Semántico
- Tags `<header>`, `<main>`, `<section>`, `<article>`, `<nav>`, `<footer>` correctamente anidados
- Atributos `alt` descriptivos en todas las imágenes
- Meta description y keywords por página
- Open Graph tags
- Breadcrumbs en páginas internas

### Páginas Nuevas / Mejoradas
- **FAQ** completo en index.html (5 preguntas frecuentes con accordion)
- **Sección Sobre Nosotros** con stats y story
- **Detalle de producto** (`gorra-trucker-frente-color.html`) con galería, specs, selector de color/cantidad
- **Header/Footer idénticos** en todas las páginas
- **Página de Llaveros** con sección "Usos populares" para mejorar conversión

## Cómo Subir a GitHub

```bash
git init
git add .
git commit -m "feat: rediseño completo Sublimarce v2.0"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/sublimarce.git
git push -u origin main
```

## Hosting Recomendado
- **GitHub Pages** (gratis): Settings > Pages > Deploy from branch main
- **Netlify** (gratis): drag & drop de la carpeta
- **Hostinger/SiteGround**: Subir por FTP/cPanel File Manager
